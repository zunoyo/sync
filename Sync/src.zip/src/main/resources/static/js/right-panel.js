/**
 * SOUNDWAVE — Right Panel Module (v3.1)
 * - 가사 fetch (lrclib.net → lyrics.ovh 폴백)
 * - 타임스탬프 가사: posMs 없어도 durationMs × progress% 로 추정
 * - 가사 로드 완료 즉시 현재 재생 위치로 점프
 * - 전체뷰 DOM 없으면 먼저 renderLyrics 후 하이라이트
 */
const RightPanel = (() => {

  let isOpen    = false;
  let activeTab = 'nowplaying';
  let _lyricsScrollEnabled = false;
  let _lyricsLines   = [];
  let _timedLines    = [];
  let _lyricsLoaded  = false;
  let _lastLyricIdx  = -1;

  /* ── Open / Close ── */
  function open() {
    const p = document.getElementById('right-panel');
    if (!p) return;
    p.classList.add('open');
    isOpen = true;
    document.getElementById('panel-toggle-btn')?.classList.add('active');
  }
  function close() {
    const p = document.getElementById('right-panel');
    if (!p) return;
    p.classList.remove('open');
    isOpen = false;
    document.getElementById('panel-toggle-btn')?.classList.remove('active');
  }
  function toggle() { isOpen ? close() : open(); }

  /* 하단 바의 '다음 곡 목록' 버튼 — 이미 열려서 큐 탭을 보고 있으면 원래대로 닫고,
     아니면 큐 탭으로 전환해서 엶 (같은 버튼을 다시 누르면 되돌아오도록) */
  function toggleQueue() {
    if (isOpen && activeTab === 'queue') {
      switchTab('nowplaying');
    } else {
      switchTab('queue');
      open();
    }
  }

  function toggleLyricsScroll() {
    _lyricsScrollEnabled = !_lyricsScrollEnabled;
    const btn = document.getElementById('lyrics-toggle-btn');
    if (btn) btn.classList.toggle('active', _lyricsScrollEnabled);

    const c = document.getElementById('rp-lyrics-container');
    if (_lyricsScrollEnabled) {
      open();
      switchTab('nowplaying');
      if (c) c.style.cssText = 'height:300px;overflow-y:auto;padding:4px 0';
      if (_lyricsLoaded) _renderLyrics();

      const playerPct = (typeof Player !== 'undefined') ? Player.getState().progress : 0;
      _lastLyricIdx = -1;

      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          syncLyrics(playerPct);
          const container = document.getElementById('rp-lyrics-container');
          const lines = container ? container.querySelectorAll('.lyrics-line') : [];
          const total  = Math.max(_lyricsLines.length, 1);
          const curIdx = Math.min(Math.floor(total * playerPct / 100), total - 1);
          if (lines[curIdx] && container) {
            const cRect = container.getBoundingClientRect();
            const lRect = lines[curIdx].getBoundingClientRect();
            const top   = container.scrollTop
                        + (lRect.top - cRect.top)
                        - (container.clientHeight / 2)
                        + (lines[curIdx].clientHeight / 2);
            container.scrollTop = Math.max(0, top);
          }
        });
      });

    } else {
      if (c) c.style.cssText = 'height:90px;overflow:hidden';
      const savedIdx = _lastLyricIdx;
      _lastLyricIdx  = -1;
      if (_lyricsLoaded && savedIdx >= 0) _renderMiniLyrics(savedIdx);
    }
  }

  /* ── 앨범아트 HTML ── */
  function _setArt(el, track) {
    if (!el) return;
    if (track?.albumArt) {
      el.className = el.id === 'rp-album-art' ? 'rp-album-art' : el.className;
      el.innerHTML = `<img src="${track.albumArt}"
        style="width:100%;height:100%;object-fit:cover;border-radius:inherit"
        onerror="this.parentElement.className+=' ${track.gradient||'grad-4'}';
                 this.parentElement.innerHTML='${track.emoji||'🎵'}'">`;
    } else {
      el.className = `${el.id==='rp-album-art'?'rp-album-art':''} ${track?.gradient||'grad-4'}`.trim();
      el.innerHTML = track?.emoji || '🎵';
    }
  }

  /* ══ 트랙 변경 시 호출 ═══════════════════════════════════ */
  function updateTrack(track) {
    _setArt(document.getElementById('rp-album-art'), track);
    const nm = document.getElementById('rp-track-name');
    const ar = document.getElementById('rp-track-artist');
    const et = document.getElementById('rp-end-time');
    if (nm) nm.textContent = track.name   || '';
    if (ar) ar.textContent = track.artist || '';
    if (et) et.textContent = track.duration || '—';
    renderQueue(track);
    renderWaveform();
    renderRelated(track);
    _fetchLyrics(track);
    if (!isOpen) open();
  }

  /* ══ 가사 fetch ══════════════════════════════════════════ */
  function _parseLrc(lrcText) {
    const result = [];
    for (const line of lrcText.split('\n')) {
      const m = line.match(/\[(\d{2}):(\d{2})\.(\d{2,3})\](.*)/);
      if (!m) continue;
      const ms   = (parseInt(m[1]) * 60 + parseInt(m[2])) * 1000
                 + parseInt(m[3].length === 2 ? m[3] : m[3].slice(0,3));
      const text = m[4].trim();
      if (text) result.push({ ms, text });
    }
    return result;
  }

  async function _fetchLyrics(track) {
    _lyricsLines  = [];
    _timedLines   = [];
    _lyricsLoaded = false;
    _lastLyricIdx = -1;

    const c = document.getElementById('rp-lyrics-container');
    if (!c) return;
    c.innerHTML = '<div style="padding:20px;text-align:center;' +
      'color:var(--text-secondary);font-size:13px;opacity:.6">가사 불러오는 중...</div>';

    if (!track?.name) return;

    /* ① lrclib.net — 타임스탬프 포함, 한국어 지원 */
    try {
      const q   = new URLSearchParams({
        artist_name: track.artist || '',
        track_name:  track.name,
      });
      const res  = await fetch(`https://lrclib.net/api/get?${q}`);
      if (res.ok) {
        const data = await res.json();
        const synced = data?.syncedLyrics;
        const plain  = data?.plainLyrics;

        if (synced) {
          _timedLines  = _parseLrc(synced);
          _lyricsLines = _timedLines.map(t => t.text);
          _lyricsLoaded = true;
          _syncToCurrentPosition();  // 로드 완료 즉시 현재 위치로 점프
          return;
        }
        if (plain) {
          _lyricsLines  = plain.split('\n').map(l => l.trim()).filter(l => l).slice(0, 60);
          _lyricsLoaded = true;
          _syncToCurrentPosition();
          return;
        }
      }
    } catch(e) {}

    /* ② lyrics.ovh — 폴백 */
    try {
      const artist = encodeURIComponent(track.artist || '');
      const title  = encodeURIComponent(track.name);
      const res    = await fetch(`https://api.lyrics.ovh/v1/${artist}/${title}`);
      const data   = await res.json();

      if (data.lyrics) {
        const raw         = data.lyrics;
        const hasKorean   = /[\uAC00-\uD7A3]/.test(raw);
        const titleKorean = /[\uAC00-\uD7A3]/.test(track.name + (track.artist||''));

        if (titleKorean && !hasKorean) {
          c.innerHTML = '<div style="padding:24px;text-align:center;' +
            'color:var(--text-secondary);font-size:13px">' +
            '한국어 가사를 찾을 수 없어요 🎵</div>';
          return;
        }
        _lyricsLines  = raw.split('\n').map(l => l.trim()).filter(l => l).slice(0, 60);
        _lyricsLoaded = true;
        _syncToCurrentPosition();
      } else {
        c.innerHTML = '<div style="padding:24px;text-align:center;' +
          'color:var(--text-secondary);font-size:13px">가사를 찾을 수 없어요 🎵</div>';
      }
    } catch(e) {
      c.innerHTML = '<div style="padding:24px;text-align:center;' +
        'color:var(--text-secondary);font-size:13px">가사를 불러올 수 없어요</div>';
    }
  }

  /* ── 가사 로드 완료 후 현재 재생 위치로 즉시 점프 ── */
  function _syncToCurrentPosition() {
    if (!_lyricsLoaded || !_lyricsLines.length) return;

    let posMs;
    if (typeof Player !== 'undefined') {
      const ps  = Player.getState();
      const pct = ps.progress || 0;

      if (ps.useSpotify && ps.currentTrack?.durationMs) {
        posMs = ps.currentTrack.durationMs * pct / 100;
      } else if (ps.useRealAudio && ps.currentTrack?.durationSec) {
        posMs = ps.currentTrack.durationSec * 1000 * pct / 100;
      }

      // 타임스탬프 가사: posMs 기반 점프
      if (_timedLines.length > 0 && posMs !== undefined) {
        let tIdx = 0;
        for (let i = 0; i < _timedLines.length; i++) {
          if (_timedLines[i].ms <= posMs) tIdx = i;
          else break;
        }
        _lastLyricIdx = tIdx;
        if (_lyricsScrollEnabled) { _renderLyrics(); _highlightLine(tIdx); }
        else _renderMiniLyrics(tIdx);
        return;
      }

      // 일반 가사: 진행률 기반 점프
      if (posMs !== undefined) {
        syncLyrics(pct, posMs);
        return;
      }
    }

    // 재생 정보 없으면 0번째 줄 표시
    _renderMiniLyrics(0);
  }

  /* ── 전체뷰 렌더링 ── */
  function _renderLyrics() {
    const c = document.getElementById('rp-lyrics-container');
    if (!c || !_lyricsLines.length) return;
    c.innerHTML = _lyricsLines.map((line, i) => {
      const seekFn = (_timedLines.length > 0 && _timedLines[i])
        ? `Player.seekMs(${_timedLines[i].ms})`
        : `Player.seek(${(i / _lyricsLines.length * 100).toFixed(1)})`;
      return `<div class="lyrics-line" data-idx="${i}"
            style="padding:8px 4px;font-size:14px;line-height:1.6;
                   cursor:pointer;transition:all .25s;color:rgba(255,255,255,0.35);
                   text-align:center;border-radius:6px;"
            onmouseenter="this.style.background='rgba(255,255,255,.05)'"
            onmouseleave="this.style.background='transparent'"
            onclick="${seekFn}">
        ${line}
      </div>`;
    }).join('');
  }

  /* ── 미니뷰 렌더링 (이전/현재/다음 3줄) ── */
  function _renderMiniLyrics(idx) {
    const c = document.getElementById('rp-lyrics-container');
    if (!c) return;
    c.style.cssText = 'height:90px;overflow:hidden;display:flex;flex-direction:column;' +
                      'justify-content:center;align-items:center;gap:2px';
    const prev    = idx > 0                       ? _lyricsLines[idx - 1] : null;
    const current = _lyricsLines[idx]             || '';
    const next    = idx < _lyricsLines.length - 1 ? _lyricsLines[idx + 1] : null;
    const rows    = [];
    if (prev)  rows.push({ text: prev,    active: false });
    rows.push(         { text: current, active: true  });
    if (next)  rows.push({ text: next,    active: false });
    c.innerHTML = rows.map(r => `
      <div class="lyrics-line ${r.active ? 'active' : ''}"
           style="padding:2px 8px;text-align:center;width:100%;
                  font-size:${r.active ? '15' : '13'}px;
                  font-weight:${r.active ? '700' : '400'};
                  color:${r.active ? 'var(--text-base)' : 'var(--text-muted)'};
                  opacity:${r.active ? '1' : '0.45'};
                  transition:all .3s;
                  white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
        ${r.text}
      </div>`).join('');
  }

  /* ── 가사 라인 하이라이트 + 자동 스크롤 ── */
  function _highlightLine(idx) {
    const c     = document.getElementById('rp-lyrics-container');
    const lines = document.querySelectorAll('#rp-lyrics-container .lyrics-line');
    if (!c || !lines.length) return;

    lines.forEach((l, i) => {
      if (i === idx) {
        l.style.color      = '#ffffff';
        l.style.fontWeight = '700';
        l.style.fontSize   = '15px';
        l.style.opacity    = '1';
        l.style.transform  = 'scale(1.03)';
        l.style.background = 'rgba(255,255,255,.04)';
        const cRect = c.getBoundingClientRect();
        const lRect = l.getBoundingClientRect();
        const top   = c.scrollTop
                    + (lRect.top - cRect.top)
                    - (c.clientHeight / 2)
                    + (l.clientHeight / 2);
        c.scrollTo({ top: Math.max(0, top), behavior: idx <= 1 ? 'instant' : 'smooth' });
      } else {
        l.style.color      = 'rgba(255,255,255,0.35)';
        l.style.fontWeight = '400';
        l.style.fontSize   = '14px';
        l.style.opacity    = '0.8';
        l.style.transform  = 'scale(1)';
        l.style.background = 'transparent';
      }
    });
  }

  /* ══ syncLyrics ══════════════════════════════════════════ */
  function syncLyrics(progressPct, posMs) {
    if (!_lyricsLoaded || !_lyricsLines.length) return;

    /* ── 타임스탬프 모드 ───────────────────────────────────
       posMs 없어도 durationMs × progress% 로 추정
    ─────────────────────────────────────────────────────── */
    if (_timedLines.length > 0) {
      let effectiveMs = posMs;
      if (effectiveMs === undefined && typeof Player !== 'undefined') {
        const ps  = Player.getState();
        const dur = ps.currentTrack?.durationMs;
        if (dur) effectiveMs = dur * progressPct / 100;
      }

      if (effectiveMs !== undefined) {
        let tIdx = 0;
        for (let i = 0; i < _timedLines.length; i++) {
          if (_timedLines[i].ms <= effectiveMs) tIdx = i;
          else break;
        }
        if (tIdx === _lastLyricIdx) return;
        _lastLyricIdx = tIdx;
        if (!_lyricsScrollEnabled) { _renderMiniLyrics(tIdx); return; }
        // 전체뷰: DOM 없으면 먼저 렌더
        const lines = document.querySelectorAll('#rp-lyrics-container .lyrics-line');
        if (!lines.length) _renderLyrics();
        _highlightLine(tIdx);
        return;
      }
    }

    /* ── iTunes 미리듣기 속도 보정 ── */
    let effectivePct = progressPct;
    if (typeof Player !== 'undefined') {
      const ps    = Player.getState();
      const track = ps.currentTrack;
      if (ps.useRealAudio && !ps.useSpotify && track && track.durationSec) {
        const PREVIEW_SEC = 30;
        if (track.durationSec > PREVIEW_SEC + 5) {
          effectivePct = progressPct * PREVIEW_SEC / track.durationSec;
        }
      }
    }

    /* ── 전주 보정 ── */
    const INTRO_PCT = 8;
    let   lyrPct    = effectivePct;
    if (effectivePct <= INTRO_PCT) {
      lyrPct = 0;
    } else {
      lyrPct = (effectivePct - INTRO_PCT) / (100 - INTRO_PCT) * 100;
    }

    const total = _lyricsLines.length;
    const idx   = Math.min(Math.floor(total * lyrPct / 100), total - 1);

    if (!_lyricsScrollEnabled) {
      if (idx === _lastLyricIdx) return;
      _lastLyricIdx = idx;
      _renderMiniLyrics(idx);
      return;
    }

    // 전체뷰: DOM 없으면 먼저 렌더
    const existingLines = document.querySelectorAll('#rp-lyrics-container .lyrics-line');
    if (!existingLines.length) _renderLyrics();
    _lastLyricIdx = idx;
    _highlightLine(idx);
  }

  /* ══ 파형 ═══════════════════════════════════════════════ */
  function renderWaveform() {
    const c = document.getElementById('rp-waveform');
    if (!c) return;
    c.innerHTML = Array.from({ length: 48 }, (_, i) =>
      `<div class="wave-bar" style="height:${20 + Math.random()*80}%"
            data-index="${i}"></div>`
    ).join('');
  }

  /* ══ 큐 렌더링 ══════════════════════════════════════════ */
  function renderQueue(currentTrack) {
    const c = document.getElementById('rp-queue-list');
    if (!c) return;

    const ps = Player.getState();
    let items = []; // { t, idx } — idx는 ps.queue 안에서 이 곡의 실제 위치(재생 시 넘겨줌)

    if (ps.queue?.length > 0) {
      items = ps.isShuffle
        // 셔플 중이면 실제로 다음에 뽑힐 순서(셔플 가방 역순)로 보여준다
        ? ps.shuffleBag.slice().reverse().map(idx => ({ t: ps.queue[idx], idx })).filter(p => p.t)
        : ps.queue.map((t, idx) => ({ t, idx })).filter(p => p.idx > ps.queueIndex);
      items = items.slice(0, 5);
    } else if (typeof TRACKS !== 'undefined') {
      items = TRACKS.filter(t => t.id !== currentTrack?.id).slice(0, 4).map(t => ({ t, idx: null }));
    }

    if (!items.length) {
      c.innerHTML = '<div style="padding:16px;text-align:center;' +
        'color:var(--text-secondary);font-size:12px">다음 곡이 없어요</div>';
      return;
    }

    c.innerHTML = items.map(({ t, idx }) => {
      const artHtml = t.albumArt
        ? `<img src="${t.albumArt}" class="queue-art"
               style="object-fit:cover;border-radius:4px"
               onerror="this.outerHTML='<div class=\\"queue-art ${t.gradient||'grad-4'}\\">${t.emoji||'🎵'}</div>'">`
        : `<div class="queue-art ${t.gradient||'grad-4'}">${t.emoji||'🎵'}</div>`;
      const trackJson = JSON.stringify(t)
        .replace(/\\/g,'\\\\').replace(/'/g,"\\'").replace(/</g,'\\u003c');
      // idx가 있으면(실제 큐 소속) 클릭 시 큐/인덱스도 같이 넘겨서 이후 이전/다음 곡 탐색이 정확히 이어지게 함
      const onclickAttr = idx != null
        ? `Player.playTrack(${trackJson}, Player.getState().queue, ${idx})`
        : `Player.playTrack(${trackJson})`;
      return `
        <div class="queue-item" onclick="${onclickAttr}">
          ${artHtml}
          <div class="queue-info">
            <div class="queue-name">${t.name}</div>
            <div class="queue-artist">${t.artist}</div>
          </div>
          <div class="queue-duration">${t.duration||'—'}</div>
        </div>`;
    }).join('');
  }

  /* ══ 탭 전환 ════════════════════════════════════════════ */
  function switchTab(tab) {
    activeTab = tab;
    document.querySelectorAll('.rp-tab').forEach(b => {
      b.classList.toggle('active', b.dataset.tab === tab);
    });
    document.querySelectorAll('.rp-tab-content').forEach(c => {
      c.style.display = c.dataset.tab === tab ? 'block' : 'none';
    });
  }

  /* ══ 관련 아티스트 ══════════════════════════════════════ */
  const _RELATED_GRADS = ['grad-1','grad-2','grad-3','grad-4','grad-5','grad-6','grad-7','grad-8'];
  let _relatedReqId = 0; // 트랙이 빠르게 바뀔 때 이전 요청 결과로 덮어쓰지 않기 위한 토큰

  /* ── iTunes 검색 — 실패(레이트리밋 등) 시 잠깐 대기 후 한 번 더 시도 ── */
  async function _fetchItunesJsonRP(url) {
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        const res = await fetch(url, { cache: 'no-store' });
        if (res.ok) return await res.json();
      } catch (e) { /* 재시도 */ }
      if (attempt === 0) await new Promise(r => setTimeout(r, 600));
    }
    return null;
  }

  async function _fetchRelatedArtists(artistName) {
    try {
      const res = await fetch(
        `https://ws.audioscrobbler.com/2.0/?method=artist.getsimilar&artist=${encodeURIComponent(artistName)}&api_key=613ca46d815b6b0b2acf0145aa03b2dd&format=json&limit=5`,
        { cache: 'no-store' }
      );
      const data = await res.json();
      const list = (data?.similarartists?.artist || []).filter(a => a.name).slice(0, 3);
      if (!list.length) return [];

      // 아티스트별 이미지 보강 (Last.fm 이미지는 대부분 깨져있어서 iTunes로 대체) — 실패 시 재시도
      return await Promise.all(list.map(async (a) => {
        const d2 = await _fetchItunesJsonRP(`https://itunes.apple.com/search?term=${encodeURIComponent(a.name)}&media=music&entity=song&limit=1`);
        const image = d2?.results?.[0]?.artworkUrl100?.replace('100x100bb', '200x200bb') || null;
        return { name: a.name, image };
      }));
    } catch (e) { return []; }
  }

  async function renderRelated(track) {
    const c = document.getElementById('rp-related-list');
    if (!c) return;
    const artistName = track?.artist;
    if (!artistName) {
      c.innerHTML = '<div style="padding:16px;text-align:center;color:var(--text-secondary);font-size:12px">아티스트 정보가 없어요</div>';
      return;
    }

    const myReqId = ++_relatedReqId;
    c.innerHTML = '<div style="padding:16px;text-align:center;color:var(--text-secondary);font-size:12px">관련 아티스트 불러오는 중...</div>';

    const related = await _fetchRelatedArtists(artistName);
    if (myReqId !== _relatedReqId) return; // 그 사이 다른 트랙으로 바뀜 — 이 결과는 버림

    if (!related.length) {
      c.innerHTML = '<div style="padding:16px;text-align:center;color:var(--text-secondary);font-size:12px">관련 아티스트를 찾을 수 없어요</div>';
      return;
    }

    c.innerHTML = related.map((a, i) => {
      const nameEsc = a.name.replace(/'/g, "\\'");
      const saved = typeof SavedLibrary !== 'undefined' && SavedLibrary.isArtistSaved(a.name);
      return `
        <div class="related-artist" style="cursor:pointer" onclick="DetailPage.showArtist('${nameEsc}')">
          <div class="related-avatar ${_RELATED_GRADS[i % _RELATED_GRADS.length]}">${a.image
            ? `<img src="${a.image}" style="width:100%;height:100%;object-fit:cover;border-radius:inherit" onerror="this.parentElement.innerHTML='🎤'">`
            : '🎤'}</div>
          <div class="related-info">
            <div class="related-name">${a.name}</div>
            <div class="related-meta">아티스트</div>
          </div>
          <button class="related-follow ${saved ? 'active' : ''}"
                  onclick="event.stopPropagation();RightPanel._toggleFollow(this,'${nameEsc}','${(a.image || '').replace(/'/g, "\\'")}')">${saved ? '팔로잉' : '팔로우'}</button>
        </div>`;
    }).join('');
  }

  /* 관련 아티스트 목록의 팔로우 버튼 — 아티스트 저장/해제와 동일하게 연결 */
  async function _toggleFollow(btn, artistName, artistImage) {
    if (typeof SavedLibrary === 'undefined') return;
    const wasSaved = SavedLibrary.isArtistSaved(artistName);

    // 낙관적 업데이트 — 응답 기다리지 않고 버튼부터 바로 바꿈
    btn.textContent = wasSaved ? '팔로우' : '팔로잉';
    btn.classList.toggle('active', !wasSaved);
    btn.disabled = true;

    const saved = await SavedLibrary.toggleArtist(artistName, artistImage || null, null);
    btn.disabled = false;

    // 실제 결과가 예상과 다르면(=진짜 실패) 원래 상태로 되돌리고 알림
    const expectedSaved = !wasSaved;
    if (saved !== expectedSaved) {
      btn.textContent = wasSaved ? '팔로잉' : '팔로우';
      btn.classList.toggle('active', wasSaved);
      console.warn('[RightPanel] 팔로우 저장 실패:', artistName);
      alert('팔로우에 실패했어요. 로그인 상태를 확인해주세요.');
    }
    if (typeof LibraryFilter !== 'undefined') LibraryFilter.refresh();
    if (typeof PlaylistPage  !== 'undefined') PlaylistPage.render(); // 전체 '내 라이브러리' 그리드 페이지도 갱신
  }

  function init() {
    renderWaveform();
    const track = Player.getState().currentTrack;
    if (track) updateTrack(track);
  }

  return {
    open, close, toggle, toggleLyricsScroll,
    updateTrack, switchTab, renderRelated, toggleQueue,
    syncLyrics, init, _toggleFollow,
  };
})();
