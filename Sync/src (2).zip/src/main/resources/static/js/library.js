/**
 * SOUNDWAVE — Library Modules
 *
 * 모듈 구성
 *   History            — history.pushState 기반 앞으로/뒤로 가기
 *   DetailPage         — 플레이리스트·아티스트·앨범 상세 뷰 (공통)
 *   CreatePlaylistModal — 플레이리스트 생성 모달
 *   LibraryFilter      — 사이드바 라이브러리 필터 (전체/플레이리스트/아티스트/앨범)
 *   PlaylistPage       — 플레이리스트 관리 페이지 (아티스트·앨범 탭 포함)
 *
 * 확장 방법
 *   새 컬렉션 유형 추가 → DetailPage._typeLabel() 에 매핑 추가
 *   새 필터 추가        → PlaylistPage.render() switch 에 케이스 추가
 */

/* ── 세션 상태 (사용자 생성 플레이리스트) ── */
const USER_PLAYLISTS = [];


/* ══════════════════════════════════════
   History — 앞으로 / 뒤로 가기
══════════════════════════════════════ */
const History = (() => {
  let _ready = false;

  function init() {
    if (_ready) return;
    _ready = true;

    // 초기 상태 기록
    history.replaceState({ pageId: 'home', context: null }, '');

    // 브라우저 앞으로/뒤로 버튼 처리
    window.addEventListener('popstate', e => {
      if (e.state) Navigation._restore(e.state.pageId, e.state.context);
    });
  }

  /** 페이지 이동 시 호출 (Navigation.switchPage 내부에서만 사용) */
  function push(pageId, context = null) {
    history.pushState({ pageId, context }, '');
  }

  return { init, push };
})();


/* ══════════════════════════════════════
   DetailPage — 공통 상세 뷰
══════════════════════════════════════ */
const DetailPage = (() => {

  /** 외부에서 호출: 상세 페이지 표시 */
  function show(config) {
    Navigation.switchPage('detail', config);
  }

  /** Navigation이 'detail' 페이지로 전환 후 내부 호출 */
  function populate(config) {
    if (!config) return;

    const hero = document.getElementById('detail-hero');
    const list = document.getElementById('detail-track-list');
    if (!hero || !list) return;

    const tracks = (config.trackIds || [])
      .map(id => TRACKS.find(t => t.id === id))
      .filter(Boolean);

    // ── 히어로 섹션 ──
    hero.className = `detail-hero ${config.gradient || 'grad-4'}`;
    hero.innerHTML = `
      <div class="detail-hero-art">${config.emoji || '🎵'}</div>
      <div class="detail-hero-info">
        <div class="detail-hero-type">${_typeLabel(config.type)}</div>
        <div class="detail-hero-name">${config.name}</div>
        ${config.description
          ? `<div class="detail-hero-desc">${config.description}</div>`
          : ''}
        <div class="detail-hero-meta">
          ${tracks.length}곡 · ${_totalDuration(tracks)}
        </div>
        <div class="detail-hero-actions">
          <button class="play-btn-large"
                  onclick="${tracks[0]
                    ? `Player.playTrack(TRACKS.find(x=>x.id===${tracks[0].id}))`
                    : ''}"
                  ${!tracks[0] ? 'disabled' : ''}
                  title="재생">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor">
              <path d="M8 5v14l11-7z"/>
            </svg>
          </button>
          <button class="action-btn" title="좋아요"
                  onclick="this.style.color=this.style.color?'':'var(--accent)'">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3
                       7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3
                       19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
            </svg>
          </button>
          <button class="action-btn" title="더보기">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1
                       0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2
                       2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/>
            </svg>
          </button>
        </div>
      </div>`;

    // ── 트랙 리스트 ──
    if (!tracks.length) {
      list.innerHTML = `
        <div style="padding:48px;text-align:center;color:var(--text-secondary)">
          <div style="font-size:36px;margin-bottom:12px">🎵</div>
          <div style="font-size:14px">아직 음악이 없어요</div>
        </div>`;
    } else {
      list.innerHTML = tracks.map((t, i) => `
        <div class="track-item"
             onclick="Player.playTrack(TRACKS.find(x=>x.id===${t.id}))">
          <div class="track-num-wrap">
            <span class="track-num">${i + 1}</span>
            <svg class="track-play-icon" width="16" height="16"
                 viewBox="0 0 24 24" fill="currentColor">
              <path d="M8 5v14l11-7z"/>
            </svg>
          </div>
          <div class="track-art ${t.gradient}">${t.emoji}</div>
          <div class="track-info">
            <div class="track-name">${t.name}</div>
            <div class="track-artist">${t.artist}</div>
          </div>
          <div class="track-album">${t.album}</div>
          <div class="track-actions">
            <button class="track-like-btn"
                    onclick="event.stopPropagation();this.classList.toggle('liked')"
                    title="좋아요">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3
                         7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3
                         19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
              </svg>
            </button>
            <span class="track-duration">${t.duration}</span>
          </div>
        </div>`).join('');
    }
  }

  /* ── 편의 메서드 ── */
  function showPlaylist(id) {
    const pl = [...PLAYLISTS, ...USER_PLAYLISTS].find(p => p.id === id);
    if (pl) show({ type: 'playlist', ...pl });
  }

  function showArtist(id) {
    const a = ARTISTS.find(x => x.id === id);
    if (a) show({ type: 'artist', ...a });
  }

  function showAlbum(id) {
    const a = ALBUMS.find(x => x.id === id);
    if (a) show({ type: 'album', ...a, description: `${a.artist} · ${a.year}` });
  }

  /** 홈 카드 등 임시 컬렉션 표시 */
  function showCollection(name, emoji, gradient, trackIds) {
    show({ type: 'collection', name, emoji, gradient, trackIds });
  }

  /* ── 내부 헬퍼 ── */
  function _typeLabel(type) {
    return { playlist:'플레이리스트', artist:'아티스트', album:'앨범',
             collection:'컬렉션', liked:'플레이리스트' }[type] || '컬렉션';
  }

  function _totalDuration(tracks) {
    const sec = tracks.reduce((s, t) => s + (t.durationSec || 0), 0);
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    return h ? `${h}시간 ${m}분` : `${m}분`;
  }

  return { show, populate, showPlaylist, showArtist, showAlbum, showCollection };
})();


/* ══════════════════════════════════════
   CreatePlaylistModal — 새 플레이리스트 생성
══════════════════════════════════════ */
const CreatePlaylistModal = (() => {

  const EMOJIS    = ['🎵','🎸','🎤','💜','🔥','🌙','⭐','🎧','🚗','📚',
                     '💚','❤️','🎹','🎺','🎻','🌊','🏃','🌅','💎','👑'];
  const GRADIENTS = ['grad-1','grad-2','grad-3','grad-4','grad-5',
                     'grad-6','grad-7','grad-8'];

  let _emoji    = '🎵';
  let _gradient = 'grad-1';

  function show() {
    const modal = document.getElementById('create-playlist-modal');
    if (!modal) return;
    _reset();
    modal.classList.remove('hidden');
    setTimeout(() => document.getElementById('cpm-name')?.focus(), 100);
  }

  function hide() {
    document.getElementById('create-playlist-modal')?.classList.add('hidden');
  }

  function create() {
    const name  = document.getElementById('cpm-name')?.value.trim();
    const errEl = document.getElementById('cpm-error');
    if (errEl) errEl.style.display = 'none';

    if (!name) {
      if (errEl) { errEl.textContent = '플레이리스트 이름을 입력해주세요.'; errEl.style.display = 'block'; }
      return;
    }

    const newPl = {
      id:            Date.now(),
      name,
      emoji:         _emoji,
      gradient:      _gradient,
      type:          '플레이리스트',
      count:         0,
      trackIds:      [],
      isUserCreated: true,
    };

    USER_PLAYLISTS.push(newPl);
    hide();

    // 플레이리스트 페이지가 활성 상태면 바로 갱신
    if (document.getElementById('page-playlist')?.classList.contains('active')) {
      PlaylistPage.render();
    }

    // 사이드바 라이브러리에 추가
    LibraryFilter.addItem(newPl);
  }

  function selectEmoji(emoji, btn) {
    _emoji = emoji;
    document.querySelectorAll('.cpm-emoji-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
  }

  function _reset() {
    const nameEl = document.getElementById('cpm-name');
    const errEl  = document.getElementById('cpm-error');
    if (nameEl) nameEl.value = '';
    if (errEl)  { errEl.style.display = 'none'; errEl.textContent = ''; }
    _emoji    = '🎵';
    _gradient = GRADIENTS[Math.floor(Math.random() * GRADIENTS.length)];
    document.querySelectorAll('.cpm-emoji-btn').forEach((b, i) => {
      b.classList.toggle('active', i === 0);
    });
  }

  return { show, hide, create, selectEmoji };
})();


/* ══════════════════════════════════════
   LibraryFilter — 사이드바 라이브러리 필터
══════════════════════════════════════ */
const LibraryFilter = (() => {

  function filter(type) {
    /* 필터 필 활성화 */
    document.querySelectorAll('.lib-filter-pill').forEach(b => b.classList.remove('active'));
    document.querySelector(`.lib-filter-pill[data-filter="${type}"]`)?.classList.add('active');

    /* 라이브러리 아이템 표시/숨김 */
    document.querySelectorAll('.library-item[data-kind]').forEach(el => {
      const kind = el.dataset.kind;
      el.style.display = (type === 'all' || kind === type) ? '' : 'none';
    });
  }

  /** 새로 만든 플레이리스트를 사이드바 라이브러리에 추가 */
  function addItem(item) {
    const list = document.querySelector('.library-list');
    if (!list) return;

    const div = document.createElement('div');
    div.className    = 'library-item';
    div.dataset.kind = 'playlist';
    div.addEventListener('click', () => DetailPage.showPlaylist(item.id));
    div.innerHTML = `
      <div class="library-item-art ${item.gradient}">${item.emoji}</div>
      <div class="library-item-info">
        <div class="library-item-name">${item.name}</div>
        <div class="library-item-meta">플레이리스트 · ${item.count}곡</div>
      </div>`;

    list.appendChild(div);
  }

  return { filter, addItem };
})();


/* ══════════════════════════════════════
   PlaylistPage — 플레이리스트 관리 (아티스트·앨범 포함)
══════════════════════════════════════ */
const PlaylistPage = (() => {

  let _filter = 'all';

  function render(filter) {
    if (filter !== undefined) _filter = filter;

    /* 활성 필터 버튼 업데이트 */
    document.querySelectorAll('.pl-filter-btn').forEach(b => b.classList.remove('active'));
    document.querySelector(`.pl-filter-btn[data-filter="${_filter}"]`)?.classList.add('active');

    const grid = document.getElementById('playlist-grid');
    if (!grid) return;

    let html = '';

    /* 플레이리스트 표시 조건 */
    const showPl = _filter === 'all' || _filter === 'my' || _filter === 'saved';
    /* 아티스트 표시 조건 */
    const showAr = _filter === 'all' || _filter === 'artist';
    /* 앨범 표시 조건 */
    const showAl = _filter === 'all' || _filter === 'album';

    if (showPl) {
      html += `
        <div class="create-playlist-banner" onclick="CreatePlaylistModal.show()">
          <div class="create-icon">➕</div>
          <div class="create-title">새 플레이리스트 만들기</div>
          <div class="create-desc">좋아하는 곡들을 모아보세요</div>
        </div>`;

      const allPl = [...PLAYLISTS, ...USER_PLAYLISTS];
      const filtered = _filter === 'saved' ? allPl.filter(p => !p.isUserCreated)
                     : _filter === 'my'    ? allPl.filter(p => p.isUserCreated || p.id <= 4)
                     :                       allPl;
      html += filtered.map(pl => _plCard(pl)).join('');
    }

    if (showAr) {
      if (_filter === 'all') html += _sectionLabel('아티스트');
      html += ARTISTS.map(a => _artistCard(a)).join('');
    }

    if (showAl) {
      if (_filter === 'all') html += _sectionLabel('앨범');
      html += ALBUMS.map(a => _albumCard(a)).join('');
    }

    grid.innerHTML = html || `
      <div style="grid-column:1/-1;padding:56px;text-align:center;color:var(--text-secondary)">
        <div style="font-size:36px;margin-bottom:12px">🎵</div>
        <div style="font-size:14px">항목이 없어요</div>
      </div>`;
  }

  /* ── 카드 렌더 ── */
  function _plCard(pl) {
    return `
      <div class="playlist-card" onclick="DetailPage.showPlaylist(${pl.id})">
        <div class="playlist-card-art ${pl.gradient}">
          <span style="font-size:52px">${pl.emoji}</span>
          <div class="playlist-card-overlay">
            <button class="detail-play-btn"
                    onclick="event.stopPropagation();
                             DetailPage.showPlaylist(${pl.id})"
                    title="재생">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                <path d="M8 5v14l11-7z"/>
              </svg>
            </button>
          </div>
        </div>
        <button class="pl-menu-btn icon-btn" onclick="event.stopPropagation()">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0
                     -2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9
                     2 2 2 2-.9 2-2-.9-2-2-2z"/>
          </svg>
        </button>
        <div class="playlist-card-body">
          <div class="playlist-card-name">${pl.name}</div>
          <div class="playlist-card-meta">${pl.type} · ${pl.count || (pl.trackIds||[]).length}곡</div>
        </div>
      </div>`;
  }

  function _artistCard(a) {
    return `
      <div class="playlist-card" onclick="DetailPage.showArtist(${a.id})"
           style="--card-radius:50%">
        <div class="playlist-card-art ${a.gradient}"
             style="border-radius:50%;overflow:visible">
          <span style="font-size:52px">${a.emoji}</span>
          <div class="playlist-card-overlay" style="border-radius:50%">
            <button class="detail-play-btn" title="재생"
                    onclick="event.stopPropagation();DetailPage.showArtist(${a.id})">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                <path d="M8 5v14l11-7z"/>
              </svg>
            </button>
          </div>
        </div>
        <div class="playlist-card-body">
          <div class="playlist-card-name">${a.name}</div>
          <div class="playlist-card-meta">아티스트 · ${a.genre}</div>
        </div>
      </div>`;
  }

  function _albumCard(a) {
    return `
      <div class="playlist-card" onclick="DetailPage.showAlbum(${a.id})">
        <div class="playlist-card-art ${a.gradient}">
          <span style="font-size:52px">${a.emoji}</span>
          <div class="playlist-card-overlay">
            <button class="detail-play-btn" title="재생"
                    onclick="event.stopPropagation();DetailPage.showAlbum(${a.id})">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                <path d="M8 5v14l11-7z"/>
              </svg>
            </button>
          </div>
        </div>
        <div class="playlist-card-body">
          <div class="playlist-card-name">${a.name}</div>
          <div class="playlist-card-meta">${a.artist} · ${a.year}</div>
        </div>
      </div>`;
  }

  function _sectionLabel(label) {
    return `<div style="grid-column:1/-1;font-size:18px;font-weight:700;
                        margin:8px 0 4px;padding:4px 0;
                        border-bottom:1px solid rgba(255,255,255,0.08)">
              ${label}
            </div>`;
  }

  return { render };
})();
