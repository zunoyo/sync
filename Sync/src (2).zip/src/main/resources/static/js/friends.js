/**
 * SOUNDWAVE — Friends Page Modules
 *
 * 모듈 구성
 *   FriendsPage        — 친구 목록 렌더 (온/오프라인 섹션)
 *   FriendDetailModal  — 친구 공유 플레이리스트 + 트랙 재생
 *   AddFriendModal     — 친구 요청 발송
 *   FriendRequestsModal — 수신 친구 요청 수락/거절
 *
 * 새 기능 추가 방법
 *   - 각 모듈은 독립 IIFE 로 분리되어 있어 개별 수정 가능
 *   - FRIEND_PLAYLISTS, FRIEND_REQUESTS 는 js/data/tracks.js 에서 관리
 */

/* ══════════════════════════════════════
   FriendsPage — 친구 목록
══════════════════════════════════════ */
const FriendsPage = (() => {

  function render() {
    const online  = FRIENDS.filter(f =>  f.online);
    const offline = FRIENDS.filter(f => !f.online);

    _renderSection('friends-online-grid',  online);
    _renderSection('friends-offline-grid', offline);

    // 온라인 카운트 업데이트
    const countEl = document.getElementById('online-count');
    if (countEl) countEl.textContent = `온라인 (${online.length})`;

    // 친구 요청 배지 업데이트
    FriendRequestsModal.updateBadge();
  }

  function _renderSection(containerId, friends) {
    const el = document.getElementById(containerId);
    if (!el) return;
    el.innerHTML = friends.map(f => `
      <div class="friend-card" onclick="FriendDetailModal.show(${f.id})">
        <div class="friend-avatar ${f.gradient}" style="color:#000">
          ${f.initials}
          <div class="online-dot ${f.online ? '' : 'offline'}"></div>
        </div>
        <div class="friend-info">
          <div class="friend-name">${f.name}</div>
          <div class="friend-status ${f.online ? 'online' : ''}">
            ${f.online ? '● 온라인' : '● 오프라인'}
          </div>
        </div>
        <svg class="friend-card-chevron" width="16" height="16"
             viewBox="0 0 24 24" fill="currentColor">
          <path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6z"/>
        </svg>
      </div>`).join('');
  }

  return { render };
})();


/* ══════════════════════════════════════
   FriendDetailModal — 공유 플레이리스트
══════════════════════════════════════ */
const FriendDetailModal = (() => {

  let _friendId         = null;
  let _expandedPlaylist = null;  // 펼쳐진 플레이리스트 id

  /* ── 표시 ── */
  function show(friendId) {
    _friendId         = friendId;
    _expandedPlaylist = null;

    const friend    = FRIENDS.find(f => f.id === friendId);
    const playlists = FRIEND_PLAYLISTS[friendId] || [];
    const modal     = document.getElementById('friend-detail-modal');
    if (!modal || !friend) return;

    // 헤더
    _setEl('fdm-avatar',  el => { el.className = `fdm-avatar ${friend.gradient}`; el.textContent = friend.initials; });
    _setEl('fdm-name',    el => { el.textContent = friend.name; });
    _setEl('fdm-status',  el => {
      el.textContent = friend.online ? '● 온라인' : '● 오프라인';
      el.className   = `fdm-status ${friend.online ? 'online' : ''}`;
    });

    // 플레이리스트 렌더
    _renderPlaylists(playlists);

    modal.classList.remove('hidden');
  }

  function hide() {
    document.getElementById('friend-detail-modal')?.classList.add('hidden');
    _expandedPlaylist = null;
  }

  /* ── 플레이리스트 아코디언 토글 ── */
  function togglePlaylist(plId) {
    _expandedPlaylist = _expandedPlaylist === plId ? null : plId;
    _renderPlaylists(FRIEND_PLAYLISTS[_friendId] || []);
  }

  /* ── 내부 렌더 ── */
  function _renderPlaylists(playlists) {
    const container = document.getElementById('fdm-playlists');
    if (!container) return;

    if (!playlists.length) {
      container.innerHTML = `
        <div style="padding:40px 24px;text-align:center;color:var(--text-secondary)">
          <div style="font-size:32px;margin-bottom:10px">🎵</div>
          <div style="font-size:13px">공유한 플레이리스트가 없어요</div>
        </div>`;
      return;
    }

    container.innerHTML = playlists.map(pl => {
      const tracks    = (pl.trackIds || []).map(id => TRACKS.find(t => t.id === id)).filter(Boolean);
      const expanded  = _expandedPlaylist === pl.id;

      return `
        <div class="fdm-playlist">
          <div class="fdm-playlist-header"
               onclick="FriendDetailModal.togglePlaylist('${pl.id}')">
            <div class="fdm-playlist-art ${pl.gradient}">${pl.emoji}</div>
            <div class="fdm-playlist-info">
              <div class="fdm-playlist-name">${pl.name}</div>
              <div class="fdm-playlist-count">${tracks.length}곡</div>
            </div>
            <div class="fdm-chevron ${expanded ? 'open' : ''}">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                <path d="M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6-6-6z"/>
              </svg>
            </div>
          </div>
          <div class="fdm-track-list ${expanded ? 'open' : ''}">
            ${tracks.map((t, i) => `
              <div class="fdm-track"
                   onclick="Player.playTrack(TRACKS.find(x=>x.id===${t.id}));FriendDetailModal.hide()">
                <span class="fdm-track-num">${i + 1}</span>
                <div class="fdm-track-art ${t.gradient}">${t.emoji}</div>
                <div class="fdm-track-info">
                  <div class="fdm-track-name">${t.name}</div>
                  <div class="fdm-track-artist">${t.artist}</div>
                </div>
                <span class="fdm-track-dur">${t.duration}</span>
                <button class="fdm-play-btn"
                        onclick="event.stopPropagation();
                                 Player.playTrack(TRACKS.find(x=>x.id===${t.id}));
                                 FriendDetailModal.hide()"
                        title="재생">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M8 5v14l11-7z"/>
                  </svg>
                </button>
              </div>`).join('')}
          </div>
        </div>`;
    }).join('');
  }

  /* ── 헬퍼 ── */
  function _setEl(id, fn) {
    const el = document.getElementById(id);
    if (el) fn(el);
  }

  return { show, hide, togglePlaylist };
})();


/* ══════════════════════════════════════
   AddFriendModal — 친구 요청 발송
══════════════════════════════════════ */
const AddFriendModal = (() => {

  function show() {
    const modal = document.getElementById('add-friend-modal');
    if (!modal) return;
    _reset();
    modal.classList.remove('hidden');
    document.getElementById('afm-input')?.focus();
  }

  function hide() {
    document.getElementById('add-friend-modal')?.classList.add('hidden');
  }

  function sendRequest() {
    const input  = document.getElementById('afm-input');
    const errEl  = document.getElementById('afm-error');
    const sucEl  = document.getElementById('afm-success');
    const btn    = document.getElementById('afm-btn');
    const value  = input?.value.trim();

    _clearMsg();

    if (!value) return _showMsg(errEl, '사용자명 또는 이메일을 입력해주세요.');

    if (btn) { btn.disabled = true; btn.textContent = '요청 중...'; }

    setTimeout(() => {
      /* 실제 서비스에서는 API 호출. 여기서는 3자 이상이면 성공 처리 */
      const ok = value.length >= 3;
      if (ok) {
        _showMsg(sucEl, `✅ 친구 요청을 보냈습니다! 상대방이 수락하면 친구가 됩니다.`);
        setTimeout(hide, 2000);
      } else {
        _showMsg(errEl, '해당 사용자를 찾을 수 없습니다. 사용자명이나 이메일을 확인해주세요.');
        if (btn) { btn.disabled = false; btn.textContent = '친구 요청 보내기'; }
      }
    }, 600);
  }

  /* ── 내부 ── */
  function _reset() {
    const input = document.getElementById('afm-input');
    const btn   = document.getElementById('afm-btn');
    if (input) input.value = '';
    if (btn)   { btn.disabled = false; btn.textContent = '친구 요청 보내기'; }
    _clearMsg();
  }

  function _clearMsg() {
    ['afm-error', 'afm-success'].forEach(id => {
      const el = document.getElementById(id);
      if (el) { el.style.display = 'none'; el.textContent = ''; }
    });
  }

  function _showMsg(el, msg) {
    if (!el) return;
    el.textContent   = msg;
    el.style.display = 'block';
  }

  return { show, hide, sendRequest };
})();


/* ══════════════════════════════════════
   FriendRequestsModal — 친구 요청 수락/거절
══════════════════════════════════════ */
const FriendRequestsModal = (() => {

  /* 수정 가능한 요청 목록 (원본 데이터 복사) */
  let _requests = FRIEND_REQUESTS.map(r => ({ ...r }));

  /* ── 표시 ── */
  function show() {
    const modal = document.getElementById('friend-requests-modal');
    if (!modal) return;
    _render();
    modal.classList.remove('hidden');
  }

  function hide() {
    document.getElementById('friend-requests-modal')?.classList.add('hidden');
  }

  /* ── 수락 ── */
  function accept(id) {
    const req = _requests.find(r => r.id === id);
    if (!req) return;
    _requests = _requests.filter(r => r.id !== id);
    /* 실제 서비스에서는 API 호출 후 FRIENDS 배열 갱신 */
    _render();
    updateBadge();
  }

  /* ── 거절 ── */
  function decline(id) {
    _requests = _requests.filter(r => r.id !== id);
    _render();
    updateBadge();
  }

  /* ── 배지 업데이트 ── */
  function updateBadge() {
    const badge = document.getElementById('friend-nav-badge');
    const btn   = document.getElementById('frm-open-btn-badge');
    const count = _requests.length;

    if (badge) {
      badge.textContent    = count;
      badge.style.display  = count ? '' : 'none';
    }
    if (btn) {
      btn.textContent    = count;
      btn.style.display  = count ? '' : 'none';
    }
  }

  /* ── 내부 렌더 ── */
  function _render() {
    const container = document.getElementById('frm-list');
    const titleEl   = document.getElementById('frm-title');

    if (titleEl) {
      titleEl.textContent = _requests.length
        ? `친구 요청 ${_requests.length}건`
        : '친구 요청';
    }

    if (!container) return;

    if (!_requests.length) {
      container.innerHTML = `
        <div style="padding:48px 24px;text-align:center;color:var(--text-secondary)">
          <div style="font-size:40px;margin-bottom:12px">🎉</div>
          <div style="font-size:14px;font-weight:700;color:var(--text-base);margin-bottom:4px">
            모두 처리됐어요!</div>
          <div style="font-size:13px">새로운 친구 요청이 없어요</div>
        </div>`;
      return;
    }

    container.innerHTML = _requests.map(req => `
      <div class="frm-item">
        <div class="frm-avatar ${req.gradient}" style="color:#000">
          ${req.initials}
        </div>
        <div class="frm-info">
          <div class="frm-name">${req.name}</div>
          <div class="frm-meta">@${req.username} · ${req.since}</div>
        </div>
        <div class="frm-actions">
          <button class="frm-accept"  onclick="FriendRequestsModal.accept(${req.id})">수락</button>
          <button class="frm-decline" onclick="FriendRequestsModal.decline(${req.id})">거절</button>
        </div>
      </div>`).join('');
  }

  function getCount() { return _requests.length; }

  return { show, hide, accept, decline, updateBadge, getCount };
})();
