/**
 * SOUNDWAVE Sync AI — API 연동
 * navigation.js의 SyncPage.sendMessage를 서버 API 버전으로 오버라이드
 */
(function () {

    var imgs          = [];
    var _audio        = null;
    var _currentTracks = [];
    var _playingIndex = -1;

    /* ── 이미지 미리보기 ─────────────────────── */
    function _renderPreviews() {
        var c = document.getElementById('sync-image-previews');
        if (!c) return;
        c.innerHTML = imgs.map(function (img, i) {
            return '<div class="sync-img-preview">' +
                '<img src="' + img.src + '">' +
                '<button class="sync-img-remove" ' +
                'onclick="SyncPage.removeImage(' + i + ')">✕</button>' +
                '</div>';
        }).join('');
    }

    /* ── 로딩 표시 ───────────────────────────── */
    function _showLoading() {
        var c = document.getElementById('sync-results');
        if (!c) return;
        c.innerHTML = [
            '<div class="ai-response">',
                '<div class="ai-response-header">',
                    '<div class="ai-icon">⏳</div>',
                    '<div>',
                        '<div class="ai-name">Sync AI</div>',
                        '<div style="font-size:11px;color:var(--text-secondary)">',
                            '감정 분석 중...',
                        '</div>',
                    '</div>',
                '</div>',
                '<p class="ai-text">잠시만 기다려주세요 🎵</p>',
            '</div>'
        ].join('');
    }

    /* ── 오류 표시 ───────────────────────────── */
    function _showError(msg) {
        var c = document.getElementById('sync-results');
        if (!c) return;
        c.innerHTML = [
            '<div class="ai-response">',
                '<div class="ai-response-header">',
                    '<div class="ai-icon">⚠️</div>',
                    '<div><div class="ai-name">오류 발생</div></div>',
                '</div>',
                '<p class="ai-text" style="color:var(--negative)">' + msg + '</p>',
            '</div>'
        ].join('');
    }

    /* ── 시간 포맷 ───────────────────────────── */
    function _fmt(ms) {
        if (!ms) return '--:--';
        var s = Math.floor(ms / 1000);
        var m = Math.floor(s / 60);
        s = s % 60;
        return m + ':' + (s < 10 ? '0' : '') + s;
    }

    /* ── 재생 상태 업데이트 ──────────────────── */
    function _setPlayingState(idx) {
        if (_playingIndex >= 0) {
            var pb = document.getElementById('spi-' + _playingIndex);
            var pt = document.getElementById('spt-' + _playingIndex);
            if (pb) pb.innerHTML = '<path d="M8 5v14l11-7z"/>';
            if (pt) pt.style.background = '';
        }
        _playingIndex = idx;
        if (idx >= 0) {
            var nb = document.getElementById('spi-' + idx);
            var nt = document.getElementById('spt-' + idx);
            if (nb) nb.innerHTML = '<path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/>';
            if (nt) nt.style.background = 'rgba(30,215,96,.08)';
        }
    }

    /* ── 플레이어 바 업데이트 ────────────────── */
    function _updateBar(t) {
        var ne = document.getElementById('player-name');
        var ae = document.getElementById('player-artist');
        var ar = document.getElementById('player-art');
        if (ne) ne.textContent = t.name   || '알 수 없음';
        if (ae) ae.textContent = t.artist || '';
        if (ar) {
            if (t.albumArt) {
                ar.style.cssText =
                    'background-image:url(' + t.albumArt + ');' +
                    'background-size:cover;background-position:center;border-radius:4px';
                ar.textContent = '';
            } else {
                ar.style.cssText = '';
                ar.textContent = '🎵';
            }
        }
    }

    /* ── 결과 렌더링 ─────────────────────────── */
    function _renderResults(data) {
        var c = document.getElementById('sync-results');
        if (!c) return;

        var em = data.emotion || {};
        var tr = data.tracks  || [];
        _currentTracks = tr;

        var labels = {
            happy:'😊 행복', sad:'😢 슬픔', calm:'😌 차분',
            energetic:'⚡ 활기', romantic:'💕 로맨틱',
            melancholy:'🌧 감성', angry:'🔥 강렬', dreamy:'🌙 몽환'
        };
        var conf = em.confidence ? Math.round(em.confidence * 100) : 0;
        var grads = ['grad-1','grad-2','grad-3','grad-4',
                     'grad-5','grad-6','grad-7','grad-8'];

        var html = [
            '<div class="ai-response">',
                '<div class="ai-response-header">',
                    '<div class="ai-icon">🤖</div>',
                    '<div>',
                        '<div class="ai-name">Sync AI</div>',
                        '<div style="font-size:11px;color:var(--text-secondary)">',
                            '감정 분석 완료',
                        '</div>',
                    '</div>',
                '</div>',
                '<div style="display:flex;gap:8px;flex-wrap:wrap;margin:12px 0">',
                    '<span style="background:var(--accent);color:#000;padding:4px 14px;',
                            'border-radius:var(--radius-full);font-size:13px;font-weight:700">',
                        labels[em.primary] || em.primary || '-',
                    '</span>',
                    em.secondary
                        ? '<span style="background:rgba(255,255,255,.1);padding:4px 14px;' +
                          'border-radius:var(--radius-full);font-size:13px">' +
                          (labels[em.secondary] || em.secondary) + '</span>'
                        : '',
                    '<span style="font-size:12px;color:var(--text-secondary);align-self:center">',
                        '신뢰도 ' + conf + '%',
                    '</span>',
                '</div>',
                '<p class="ai-text">',
                    '감정 분석 결과를 바탕으로 ' + tr.length + '곡을 추천해드려요! 🎵',
                '</p>',
            '</div>'
        ].join('');

        if (tr.length === 0) {
            html += [
                '<div style="padding:32px;text-align:center;color:var(--text-secondary)">',
                    '<div style="font-size:32px;margin-bottom:12px">🔍</div>',
                    '<div>추천할 트랙을 찾지 못했어요.<br>',
                    'Last.fm / Spotify API Key를 확인하거나<br>',
                    '다른 감정으로 다시 시도해보세요.</div>',
                '</div>'
            ].join('');
        } else {
            tr.forEach(function (t, i) {
                var dur = _fmt(t.durationMs);
                var g   = grads[i % grads.length];
                var art = t.albumArt
                    ? '<img src="' + t.albumArt + '" onerror="this.style.display=\'none\'" ' +
                      'style="width:44px;height:44px;border-radius:6px;' +
                      'object-fit:cover;flex-shrink:0">'
                    : '<div class="track-art ' + g + '" style="width:44px;height:44px;' +
                      'border-radius:6px;display:flex;align-items:center;' +
                      'justify-content:center;font-size:18px;flex-shrink:0">🎵</div>';

                var btn = t.previewUrl
                    ? '<button id="spb-' + i + '" class="ctrl-btn" ' +
                      'onclick="event.stopPropagation();SyncPage.playPreview(' + i + ')" ' +
                      'style="color:var(--accent)" title="미리듣기">' +
                      '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">' +
                      '<path id="spi-' + i + '" d="M8 5v14l11-7z"/></svg></button>'
                    : '<span style="font-size:11px;color:var(--text-muted)">미리듣기 없음</span>';

                html += [
                    '<div class="sync-track-rec" id="spt-' + i + '" ',
                        'onclick="SyncPage.playPreview(' + i + ')">',
                        art,
                        '<div style="flex:1;overflow:hidden">',
                            '<div style="font-size:14px;font-weight:700;overflow:hidden;',
                                    'text-overflow:ellipsis;white-space:nowrap">',
                                t.name || '알 수 없음',
                            '</div>',
                            '<div style="font-size:12px;color:var(--text-secondary)">',
                                (t.artist || '') + (t.album ? ' · ' + t.album : ''),
                            '</div>',
                        '</div>',
                        '<div style="display:flex;align-items:center;gap:8px">',
                            '<span style="font-size:12px;color:var(--text-muted)">' + dur + '</span>',
                            btn,
                        '</div>',
                    '</div>'
                ].join('');
            });

            if (data.historyId) {
                html += [
                    '<div style="display:flex;gap:8px;justify-content:center;',
                            'margin-top:16px;padding-top:16px;',
                            'border-top:1px solid rgba(255,255,255,.07)">',
                        '<span style="font-size:13px;color:var(--text-secondary);align-self:center">',
                            '이 추천이 마음에 드셨나요?',
                        '</span>',
                        '<button onclick="SyncPage.feedback(' + data.historyId + ',1)" ',
                            'style="background:rgba(30,215,96,.15);border:1px solid var(--accent);',
                            'color:var(--accent);padding:6px 16px;border-radius:var(--radius-full);',
                            'font-size:13px;cursor:pointer;font-family:var(--font)">',
                            '👍 좋아요',
                        '</button>',
                        '<button onclick="SyncPage.feedback(' + data.historyId + ',0)" ',
                            'style="background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.15);',
                            'color:var(--text-secondary);padding:6px 16px;',
                            'border-radius:var(--radius-full);font-size:13px;',
                            'cursor:pointer;font-family:var(--font)">',
                            '👎 별로예요',
                        '</button>',
                    '</div>'
                ].join('');
            }
        }

        c.innerHTML = html;
    }

    /* ── 미리듣기 재생 ───────────────────────── */
    function _playPreview(idx) {
        var t = _currentTracks[idx];
        if (!t) return;

        if (!t.previewUrl) {
            alert('이 트랙은 미리듣기가 제공되지 않습니다.');
            return;
        }

        if (_playingIndex === idx && _audio && !_audio.paused) {
            _audio.pause();
            _setPlayingState(-1);
            return;
        }

        if (_audio) {
            _audio.pause();
            _audio.src = t.previewUrl;
            _audio.play().catch(function (e) {
                console.warn('재생 실패:', e);
            });
        }

        _setPlayingState(idx);
        _updateBar(t);

        fetch('/api/play-history', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({
                spotifyTrackId: t.spotifyTrackId || '',
                trackName:      t.name   || '',
                artistName:     t.artist || '',
                source:         'sync_rec',
                emotionVectorId: null
            })
        }).catch(function () {});
    }

    /* ── 피드백 ──────────────────────────────── */
    function _feedback(historyId, val) {
        fetch('/api/sync/feedback/' + historyId, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({ feedback: val })
        }).then(function () {
            alert(val === 1 ? '👍 피드백 감사합니다!' : '👎 더 좋은 추천을 위해 노력할게요!');
        }).catch(function () {});
    }

    /* ── 이미지 제거 ─────────────────────────── */
    function _removeImage(i) {
        imgs.splice(i, 1);
        _renderPreviews();
    }

    /* ── 메시지 전송 (핵심) ─────────────────── */
    function _sendMessage() {
        var ta   = document.getElementById('sync-textarea');
        var text = ta ? ta.value.trim() : '';

        if (!text && imgs.length === 0) {
            alert('텍스트나 이미지를 입력해주세요.');
            return;
        }

        _showLoading();

        var inputType = 'text';
        if (text && imgs.length > 0) inputType = 'both';
        else if (imgs.length > 0)    inputType = 'image';

        var req = {
            inputType: inputType,
            inputText: text || null,
            imageUrl:  imgs.length > 0 ? imgs[0].src : null
        };

        if (ta) ta.value = '';
        imgs = [];
        _renderPreviews();

        fetch('/api/sync/full-recommend', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify(req)
        })
        .then(function (res) {
            if (res.status === 401) throw new Error('로그인이 필요합니다. 다시 로그인해주세요.');
            if (!res.ok) return res.json().then(function (e) {
                throw new Error(e.error || '추천 실패 (status: ' + res.status + ')');
            });
            return res.json();
        })
        .then(function (data) {
            _renderResults(data);
        })
        .catch(function (e) {
            _showError(e.message);
        });
    }

    /* ── 초기화 (DOMContentLoaded 후 실행) ──── */
    document.addEventListener('DOMContentLoaded', function () {
        _audio = new Audio();

        // 이미지 첨부 이벤트
        var ab = document.getElementById('sync-attach-btn');
        var fi = document.getElementById('sync-file-input');
        if (ab && fi) {
            ab.addEventListener('click', function () { fi.click(); });
            fi.addEventListener('change', function (e) {
                Array.from(e.target.files).forEach(function (file) {
                    if (!file.type.startsWith('image/')) return;
                    var r = new FileReader();
                    r.onload = function (ev) {
                        imgs.push({ name: file.name, src: ev.target.result });
                        _renderPreviews();
                    };
                    r.readAsDataURL(file);
                });
                fi.value = '';
            });
        }

        // 오디오 종료 이벤트
        _audio.addEventListener('ended', function () { _setPlayingState(-1); });

        // ✅ SyncPage 메서드 오버라이드 (navigation.js const 선언 이후 프로퍼티만 변경)
        if (typeof SyncPage !== 'undefined') {
            SyncPage.sendMessage = _sendMessage;
            SyncPage.playPreview = _playPreview;
            SyncPage.removeImage = _removeImage;
            SyncPage.feedback    = _feedback;
        }
    });

})();
