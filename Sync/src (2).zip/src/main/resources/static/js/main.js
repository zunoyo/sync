/**
 * SOUNDWAVE — Main Entry Point
 */
function init() {
  Player.init();
  RightPanel.init();
  HomePage.init();
  Navigation.init();
  History.init();           /* 앞으로/뒤로 버튼 활성화 */
  // TrackList.renderAll() → HomePage.init() 이 비동기로 처리

  document.querySelectorAll('.filter-pill').forEach(btn => {
    btn.addEventListener('click', function () {
      document.querySelectorAll('.filter-pill').forEach(b => b.classList.remove('active'));
      this.classList.add('active');
    });
  });

  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', function () {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      this.classList.add('active');
    });
  });

  document.querySelectorAll('.rp-tab').forEach(btn => {
    btn.addEventListener('click', function () { RightPanel.switchTab(this.dataset.tab); });
  });

  const avatarBtn = document.getElementById('avatar-btn');
  const dropdown  = document.getElementById('avatar-dropdown');
  if (avatarBtn && dropdown) {
    avatarBtn.addEventListener('click', e => {
      e.stopPropagation();
      dropdown.classList.toggle('open');
    });
    dropdown.addEventListener('click', e => e.stopPropagation());
    document.addEventListener('click', e => {
      if (!dropdown.contains(e.target) && e.target !== avatarBtn) {
        dropdown.classList.remove('open');
      }
    });
  }

  const searchInput = document.getElementById('search-input');
  if (searchInput) searchInput.addEventListener('focus', () => Navigation.switchPage('search'));

  // Spotify SDK 초기화 (로그인된 사용자)
  // 페이지 로드 후 1.5초 대기 → auth 상태 확정 후 시도
  setTimeout(() => {
    if (typeof SpotifyPlayer !== 'undefined' &&
        typeof Auth !== 'undefined' && Auth.isLoggedIn()) {
      SpotifyPlayer.init();
    }
  }, 1500);

  if (typeof ProfileModule !== 'undefined') ProfileModule.init();
  if (typeof SearchPage !== 'undefined') SearchPage.init();
  console.log('🎵 SoundWave initialized');
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

function switchPage(id)     { Navigation.switchPage(id); }
function togglePlay()       { Player.togglePlay(); }
function toggleShuffle()    { Player.toggleShuffle(); }
function toggleRepeat()     { Player.toggleRepeat(); }
function togglePlayerLike() { Player.toggleLike(); }
function togglePanel()      { RightPanel.toggle(); }
function closePanel()       { RightPanel.close(); }
function syncSend()         { SyncPage.sendMessage(); }
