package com.graduate.Sync.service;

import com.graduate.Sync.entity.FriendsListEntity;
import com.graduate.Sync.entity.UserEntity;
import com.graduate.Sync.repository.FriendsListRepository;
import com.graduate.Sync.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class FriendService {

    @Autowired
    private FriendsListRepository friendsListRepository;

    @Autowired
    private UserRepository userRepository;

    // 수락된 친구 목록
    public List<FriendsListEntity> getFriends(UserEntity user) {
        return friendsListRepository.findByUserAndStatus(user, "ACCEPTED");
    }

    // 받은 친구 요청 (PENDING)
    public List<FriendsListEntity> getPendingRequests(UserEntity user) {
        return friendsListRepository.findByFriendAndStatus(user, "PENDING");
    }

    // 친구 요청 발송
    public boolean sendRequest(UserEntity from, String targetEmailOrUsername) {
        UserEntity target = userRepository.findByEmail(targetEmailOrUsername)
                .or(() -> userRepository.findByUsername(targetEmailOrUsername))
                .orElse(null);

        if (target == null || target.getId().equals(from.getId())) return false;

        // 이미 요청이 있으면 중복 방지
        if (friendsListRepository.findByUserAndFriend(from, target).isPresent()) return false;

        FriendsListEntity request = new FriendsListEntity(null, from, target, "PENDING", null, null);
        friendsListRepository.save(request);
        return true;
    }

    // 친구 요청 수락
    @Transactional
    public void acceptRequest(Long requestId, UserEntity loginUser) {
        FriendsListEntity req = friendsListRepository.findById(requestId).orElse(null);
        if (req == null || !req.getFriend().getId().equals(loginUser.getId())) return;

        req.accept();
        friendsListRepository.save(req);

        // 양방향 친구 관계 생성
        FriendsListEntity reverse = new FriendsListEntity(null, loginUser, req.getUser(), "ACCEPTED", null, null);
        friendsListRepository.save(reverse);
    }

    // 친구 요청 거절
    public void rejectRequest(Long requestId, UserEntity loginUser) {
        FriendsListEntity req = friendsListRepository.findById(requestId).orElse(null);
        if (req == null || !req.getFriend().getId().equals(loginUser.getId())) return;

        req.reject();
        friendsListRepository.save(req);
    }
}
