package com.graduate.Sync.dto;

import com.graduate.Sync.entity.PlaylistEntity;
import com.graduate.Sync.entity.PlaylistTrackEntity;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PlaylistTrackDTO {

    private Long    id;
    private Long    playlistId;

    // Last.fm (필수)
    private String  lastfmTrackName;
    private String  lastfmArtistName;

    // Spotify (선택)
    private String  spotifyTrackId;
    private String  spotifyTrackName;
    private String  spotifyArtistName;
    private String  spotifyAlbumName;
    private String  spotifyAlbumArtUrl;
    private String  spotifyPreviewUrl;
    private Integer spotifyDurationMs;

    private int     orderIndex;

    public PlaylistTrackEntity toEntity(PlaylistEntity playlist) {
        return new PlaylistTrackEntity(
            null,
            playlist,
            lastfmTrackName,
            lastfmArtistName,
            spotifyTrackId,
            spotifyTrackName,
            spotifyArtistName,
            spotifyAlbumName,
            spotifyAlbumArtUrl,
            spotifyPreviewUrl,
            spotifyDurationMs,
            orderIndex,
            null
        );
    }
}
