package com.graduate.Sync.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Entity
@Table(name = "playlist_track")
public class PlaylistTrackEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "playlist_id", nullable = false)
    private PlaylistEntity playlist;

    // Last.fm 정보 (필수)
    @Column(name = "lastfm_track_name", nullable = false, length = 255)
    private String lastfmTrackName;

    @Column(name = "lastfm_artist_name", nullable = false, length = 255)
    private String lastfmArtistName;

    // Spotify 정보 (모두 NULL 허용)
    @Column(name = "spotify_track_id", length = 100)
    private String spotifyTrackId;

    @Column(name = "spotify_track_name", length = 255)   // ✅ nullable=true
    private String spotifyTrackName;

    @Column(name = "spotify_artist_name", length = 255)  // ✅ nullable=true
    private String spotifyArtistName;

    @Column(name = "spotify_album_name", length = 255)
    private String spotifyAlbumName;

    @Column(name = "spotify_album_art_url", length = 500)
    private String spotifyAlbumArtUrl;

    @Column(name = "spotify_preview_url", length = 500)
    private String spotifyPreviewUrl;

    @Column(name = "spotify_duration_ms")
    private Integer spotifyDurationMs;

    @Column(name = "order_index", columnDefinition = "INT DEFAULT 0")
    private int orderIndex = 0;

    @Column(name = "added_at")
    private LocalDateTime addedAt;

    @PrePersist
    public void prePersist() {
        this.addedAt = LocalDateTime.now();
    }
}
