package com.graduate.Sync.api;

import com.graduate.Sync.dto.PlaylistDTO;
import com.graduate.Sync.dto.PlaylistTrackDTO;
import com.graduate.Sync.entity.PlaylistEntity;
import com.graduate.Sync.entity.PlaylistTrackEntity;
import com.graduate.Sync.entity.UserEntity;
import com.graduate.Sync.service.PlaylistService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class PlaylistApiController {

    @Autowired
    private PlaylistService playlistService;

    // 내 플레이리스트 목록
    @GetMapping("/api/playlists")
    public List<PlaylistEntity> index(HttpSession session) {
        UserEntity loginUser = (UserEntity) session.getAttribute("loginUser");
        return playlistService.index(loginUser);
    }

    // 플레이리스트 단건 조회
    @GetMapping("/api/playlists/{id}")
    public ResponseEntity<PlaylistEntity> show(@PathVariable Long id) {
        PlaylistEntity result = playlistService.show(id);
        if (result == null) return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        return ResponseEntity.ok(result);
    }

    // 플레이리스트 생성
    @PostMapping("/api/playlists")
    public ResponseEntity<PlaylistEntity> create(@RequestBody PlaylistDTO dto,
                                                  HttpSession session) {
        UserEntity loginUser = (UserEntity) session.getAttribute("loginUser");
        PlaylistEntity created = playlistService.create(dto, loginUser);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    // 플레이리스트 삭제
    @DeleteMapping("/api/playlists/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        playlistService.delete(id);
        return ResponseEntity.status(HttpStatus.OK).build();
    }

    // 트랙 목록 조회
    @GetMapping("/api/playlists/{id}/tracks")
    public ResponseEntity<List<PlaylistTrackEntity>> getTracks(@PathVariable Long id) {
        PlaylistEntity playlist = playlistService.show(id);
        if (playlist == null) return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        return ResponseEntity.ok(playlistService.getTracks(playlist));
    }

    // 트랙 추가
    @PostMapping("/api/playlists/{id}/tracks")
    public ResponseEntity<PlaylistTrackEntity> addTrack(@PathVariable Long id,
                                                         @RequestBody PlaylistTrackDTO dto) {
        PlaylistEntity playlist = playlistService.show(id);
        if (playlist == null) return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        PlaylistTrackEntity track = playlistService.addTrack(dto, playlist);
        return ResponseEntity.status(HttpStatus.CREATED).body(track);
    }

    // 트랙 삭제
    @DeleteMapping("/api/playlists/tracks/{trackId}")
    public ResponseEntity<Void> deleteTrack(@PathVariable Long trackId) {
        playlistService.deleteTrack(trackId);
        return ResponseEntity.status(HttpStatus.OK).build();
    }
}
