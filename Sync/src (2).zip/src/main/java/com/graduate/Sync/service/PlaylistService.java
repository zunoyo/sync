package com.graduate.Sync.service;

import com.graduate.Sync.dto.PlaylistDTO;
import com.graduate.Sync.dto.PlaylistTrackDTO;
import com.graduate.Sync.entity.PlaylistEntity;
import com.graduate.Sync.entity.PlaylistTrackEntity;
import com.graduate.Sync.entity.UserEntity;
import com.graduate.Sync.repository.PlaylistRepository;
import com.graduate.Sync.repository.PlaylistTrackRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class PlaylistService {

    @Autowired
    private PlaylistRepository playlistRepository;

    @Autowired
    private PlaylistTrackRepository playlistTrackRepository;

    // 사용자 플레이리스트 전체 조회 최신순
    public List<PlaylistEntity> index(UserEntity user) {
        return playlistRepository.findByUserOrderByCreatedAtDesc(user);
    }

    // 단건 조회
    public PlaylistEntity show(Long id) {
        return playlistRepository.findById(id).orElse(null);
    }

    // 플레이리스트 생성
    public PlaylistEntity create(PlaylistDTO dto, UserEntity user) {
        PlaylistEntity entity = dto.toEntity(user);
        return playlistRepository.save(entity);
    }

    // 플레이리스트 삭제
    @Transactional
    public void delete(Long id) {
        PlaylistEntity target = playlistRepository.findById(id).orElse(null);
        if (target != null) {
            playlistTrackRepository.deleteByPlaylist(target);
            playlistRepository.delete(target);
        }
    }

    // 트랙 목록 조회 (순서 정렬)
    public List<PlaylistTrackEntity> getTracks(PlaylistEntity playlist) {
        return playlistTrackRepository.findByPlaylistOrderByOrderIndex(playlist);
    }

    // 트랙 추가
    //  중복 확인 + orderIndex 자동 계산
    public PlaylistTrackEntity addTrack(PlaylistTrackDTO dto,
                                        PlaylistEntity playlist) {
        // 중복 트랙 확인
        boolean isDuplicate = playlistTrackRepository.existsByPlaylistAndSpotifyTrackId(playlist, dto.getSpotifyTrackId());

        if (isDuplicate) {
            return null;  // 이미 추가된 트랙
        }

        // 마지막 orderIndex 확인 후 다음 순서 자동 계산
        List<PlaylistTrackEntity> tracks = playlistTrackRepository.findByPlaylistOrderByOrderIndexDesc(playlist);

        int nextOrder = tracks.isEmpty() ? 1 : tracks.get(0).getOrderIndex() + 1;

        dto.setOrderIndex(nextOrder);
        PlaylistTrackEntity entity = dto.toEntity(playlist);

        return playlistTrackRepository.save(entity);
    }

    // 트랙 삭제
    public void deleteTrack(Long trackId) {
        playlistTrackRepository.deleteById(trackId);
    }

    // source 별 플레이리스트 조회
    public List<PlaylistEntity> getBySource(UserEntity user, String source) {
        return playlistRepository.findByUserAndSourceOrderByCreatedAtDesc(user, source);
    }
}
